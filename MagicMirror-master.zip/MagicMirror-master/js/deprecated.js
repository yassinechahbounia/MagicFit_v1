module.exports = {
	configs: ["kioskmode"],
	clock: ["secondsColor"]
};
