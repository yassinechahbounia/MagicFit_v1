# Module: Compliments

The `compliments` module is one of the default modules of the MagicMirror².
This module displays a random compliment.

For configuration options, please check the [MagicMirror² documentation](https://docs.magicmirror.builders/modules/compliments.html).
